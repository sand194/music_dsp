This directory contains sources for utility programs used by the fonts
package.

## ttf2pt1

The sources for ttf2pt1 have had a number of changes from the original version 3.4.4, which was last updated in 2003.

To see the commits that have changed ttf2pt1 from the original sources, go to https://github.com/wch/Rttf2pt1/commits/master/src/ttf2pt1.
