
# required packages
library(testthat)
library(fstcore)
library(lintr)

# run tests
test_check("fstcore")
