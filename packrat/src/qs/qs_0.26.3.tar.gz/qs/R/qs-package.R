#' @useDynLib qs, .registration = TRUE
#' @keywords internal
#' @import RApiSerialize
#' @import stringfish
#' @importFrom Rcpp evalCpp
"_PACKAGE"
