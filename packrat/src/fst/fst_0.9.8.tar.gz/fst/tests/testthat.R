
# required packages
library(testthat)
library(fst)

# run tests
test_check("fst")
