# retrofit_files() works

    The `outfile` argument of `reprex()` is deprecated as of reprex 2.0.0.
    i Please use the `wd` argument instead.

---

    The `outfile` argument of `reprex()` is deprecated as of reprex 2.0.0.
    i Use `reprex(wd = ".")` instead of `reprex(outfile = NA)`.

---

    The `outfile` argument of `reprex()` is deprecated as of reprex 2.0.0.
    i To control output filename, provide a filepath to `input`.
    i Only taking working directory from `outfile`.

---

    The `outfile` argument of `reprex()` is deprecated as of reprex 2.0.0.
    i Working directory will be derived from `input`.

---

    The `outfile` argument of `reprex()` is deprecated as of reprex 2.0.0.
    i Working directory and output filename will be determined from `input`.

