foo <- function() {
  a_really_really_long_local_object_name <- 1
}
