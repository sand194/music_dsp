# lint errors should be included in test-lint_package.R
x = 1:4
res<- lapply(x, function(y) y+1)
