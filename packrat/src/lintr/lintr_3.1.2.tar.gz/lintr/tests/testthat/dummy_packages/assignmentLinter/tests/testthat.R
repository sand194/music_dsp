library(testthat)
library(assignmentLinter)

test_check("assignmentLinter")
