#' eat_me
#' @description empty
#'
#' @export
eat_me <- function(x, ...) {
  UseMethod("drink_me")
}
