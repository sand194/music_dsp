# Each of the default linters should throw at least one lint for assignment_linter or object_name_linter on this file
x = 1:4
res <- lapply(x, function(y) y + 1)
