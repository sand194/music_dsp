downstream <- function(x) {
  a_really_really_long_local_object_name <- 1
  aSilLLyObjEctNaME <- 2

  myFancyUpstream::upstreams_really_long_imported_object_name()
  myFancyUpstream::uPStreams_SilLY.objecT.Name()
}

# importFrom() functions in unknown namespace
a_veritably_dilettantish_function.my_class <- function(x, ...) x
sPoNgEbOb_cAsE.FuNcTiOn.my_class <- function(x, ...) x
