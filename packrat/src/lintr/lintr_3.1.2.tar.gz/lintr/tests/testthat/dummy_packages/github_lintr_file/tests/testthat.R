library(testthat)

test_check('github_lintr_file')  # nolint
