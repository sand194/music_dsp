#' head on my_s3_object
#' @export
head.my_s3_object <- function(x, ...) {
  1
}
