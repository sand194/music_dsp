

#nolint start

c(1,2)
