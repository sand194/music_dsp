#include "pcre2.h"

int pcre2_is_bundled(void) {
  return 1;
}
