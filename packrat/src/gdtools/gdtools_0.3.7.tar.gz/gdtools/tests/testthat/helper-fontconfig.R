
local <- function() {
  identical(Sys.getenv("NOT_CRAN"), "true")
}

