library(testthat)
library(gdtools)

test_check("gdtools")
