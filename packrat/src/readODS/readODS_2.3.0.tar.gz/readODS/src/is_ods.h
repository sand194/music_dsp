#pragma once

#include <string>
#include "readxl/zip.h"

bool is_ods(const std::string file);
bool is_flat_ods(const std::string file);
