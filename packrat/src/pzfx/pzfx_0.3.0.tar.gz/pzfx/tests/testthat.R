library(testthat)
library(pzfx)

test_check("pzfx")
