
# Just for use in examples in hexView help files 
hexViewFile <- function(filename) {
  system.file("files", package="hexView", filename)
}

