test_that("stat_fivenumber works", {
  expect_s3_class(stat_fivenumber(), "LayerInstance")
})
