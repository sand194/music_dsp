test_that("geom_rangeframe works", {
  expect_s3_class(geom_rangeframe(), "LayerInstance")
})
