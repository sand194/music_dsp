test_that("geom_tufteboxplot works", {
  expect_s3_class(geom_tufteboxplot(), "LayerInstance")
})
