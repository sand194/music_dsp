# for installation, see https://github.com/rstudio/shiny
library(shiny)
runApp(system.file('shiny', package = 'knitr'))
